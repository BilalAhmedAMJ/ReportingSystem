<html>
<head>
<title>Ahmadiyya Muslim Community Canada</title>
<META http-equiv="refresh" content="0;URL=http://report.ahmadiyya.ca/reports/login.php">
</head>
<body bgcolor="#ffffff">
</body>
</html>
