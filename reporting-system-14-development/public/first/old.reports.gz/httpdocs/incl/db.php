<?php

$linkcon = mysql_connect("127.0.0.1", "ahmadiyya", "TinyBoy4T!") or die("Could not connect");
mysql_select_db("ahmadiyya_ca_-_site", $linkcon);

?>