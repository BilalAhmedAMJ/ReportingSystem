<?php
if ($_SERVER['HTTPS']!='on') {
                $url='https://report.ahmadiyya.ca'.$_SERVER['REQUEST_URI'];
                  header('location: '.$url);
                  exit;
        }

  $dbname   = 'amjc_reports'; 
  $hostname = 'localhost';
  $username = 'amjc_db_user'; 
  $password = 'TinyBoy4T!';
  $id_link = mysql_connect($hostname, $username, $password);

  if (!$id_link) {
    print "Error connecting to mysql server.";
    exit();
  }
?>
